import { useState, useEffect, useRef, useCallback } from "react";

export const PURIFICATION_CAPACITY = 1000;
export const MAIN_TANK_CAPACITY = 500;
export const HOUSE_WALLET_MAX = 1000;
export const WATER_COST_PER_LITER = 5;
const CONSUMPTION_RATE = 1.5; // liters per tick (scaled below)
const MAIN_TANK_REFILL_START_PCT = 0.8;
const MAIN_TANK_REFILL_STOP_PCT = 0.95;

export type House = {
  id: number;
  name: string;
  wallet: number;
  consuming: boolean;
  consumed: number;
};

const INITIAL_HOUSES: House[] = [
  { id: 1, name: "House 1", wallet: 125, consuming: false, consumed: 25 },
  { id: 2, name: "House 2", wallet: 75, consuming: false, consumed: 15 },
  { id: 3, name: "House 3", wallet: 25, consuming: false, consumed: 13 },
  { id: 4, name: "House 4", wallet: 200, consuming: false, consumed: 5 },
];

export function useWaterSystem() {
  const [purificationLevel, setPurificationLevel] = useState(320);
  const [mainTankLevel, setMainTankLevel] = useState(435);
  const [purificationActive, setPurificationActive] = useState(true);
  const [pumpR2P, setPumpR2P] = useState(true); // reservoir → purification
  const [pumpP2M, setPumpP2M] = useState(false); // purification → main
  const [houses, setHouses] = useState<House[]>(INITIAL_HOUSES);

  const tickRef = useRef<ReturnType<typeof setInterval> | null>(null);

  const togglePumpR2P = useCallback(() => setPumpR2P((p) => !p), []);
  const togglePumpP2M = useCallback(() => setPumpP2M((p) => !p), []);
  const togglePurification = useCallback(() => setPurificationActive((p) => !p), []);

  const rechargeWallet = useCallback((houseId: number, amount: number) => {
    setHouses((prev) =>
      prev.map((h) =>
        h.id === houseId
          ? { ...h, wallet: Math.min(HOUSE_WALLET_MAX, h.wallet + amount) }
          : h,
      ),
    );
  }, []);

  const toggleConsumption = useCallback((houseId: number) => {
    setHouses((prev) =>
      prev.map((h) => (h.id === houseId ? { ...h, consuming: !h.consuming } : h)),
    );
  }, []);

  const resetSystem = useCallback(() => {
    setPurificationLevel(320);
    setMainTankLevel(435);
    setPurificationActive(true);
    setPumpR2P(true);
    setPumpP2M(false);
    setHouses(INITIAL_HOUSES);
  }, []);

  // Simulation tick
  useEffect(() => {
    tickRef.current = setInterval(() => {
      // Reservoir → Purification (reservoir treated as infinite for simplicity)
      if (pumpR2P && purificationActive) {
        setPurificationLevel((pl) => Math.min(PURIFICATION_CAPACITY, pl + 2.5));
      }

      // Purification → Main tank with hysteresis
      setPurificationLevel((pl) => {
        const mainPct = mainTankLevel / MAIN_TANK_CAPACITY;
        const shouldFill =
          pl > 30 &&
          (pumpP2M ? mainPct < MAIN_TANK_REFILL_STOP_PCT : mainPct <= MAIN_TANK_REFILL_START_PCT);

        if (shouldFill) {
          setPumpP2M(true);
          const flow = 3.5;
          setMainTankLevel((mt) => Math.min(MAIN_TANK_CAPACITY, mt + flow));
          return Math.max(0, pl - flow);
        }
        if (pumpP2M && mainPct >= MAIN_TANK_REFILL_STOP_PCT) {
          setPumpP2M(false);
        }
        return pl;
      });

      // House consumption — Cost = Rs.5 × liters consumed
      setHouses((prev) =>
        prev.map((h) => {
          if (!h.consuming || h.wallet <= 0 || mainTankLevel <= 0) {
            return { ...h, consuming: h.wallet > 0 ? h.consuming : false };
          }
          const usage = CONSUMPTION_RATE * (0.8 + Math.random() * 0.4) * 0.25; // L per tick
          const cost = usage * WATER_COST_PER_LITER;
          const newWallet = Math.max(0, h.wallet - cost);
          setMainTankLevel((mt) => Math.max(0, mt - usage));
          return {
            ...h,
            wallet: newWallet,
            consumed: h.consumed + usage,
            consuming: newWallet > 0,
          };
        }),
      );
    }, 500);

    return () => {
      if (tickRef.current) clearInterval(tickRef.current);
    };
  }, [pumpR2P, pumpP2M, purificationActive, mainTankLevel]);

  return {
    purificationLevel,
    mainTankLevel,
    purificationActive,
    pumpR2P,
    pumpP2M,
    houses,
    togglePumpR2P,
    togglePumpP2M,
    togglePurification,
    rechargeWallet,
    toggleConsumption,
    resetSystem,
    PURIFICATION_CAPACITY,
    MAIN_TANK_CAPACITY,
    HOUSE_WALLET_MAX,
  };
}

export type WaterSystem = ReturnType<typeof useWaterSystem>;
