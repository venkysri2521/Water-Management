import "./WaterSystem.css";
import type { WaterSystem as WaterSystemType } from "@/hooks/useWaterSystem";

function PipeSegment({ flowing = false }: { flowing?: boolean }) {
  return (
    <div className="wm-segment" aria-hidden="true">
      <div className="wm-segment-base" />
      <div className={`wm-segment-flow ${flowing ? "is-flowing" : ""}`} />
    </div>
  );
}

function SideTank({
  title,
  level,
  maxLevel,
  side,
  showScale = true,
  valueLabel = null,
  onClick,
  active = false,
  interactiveLabel,
}: {
  title: string;
  level: number;
  maxLevel: number;
  side: "left" | "right";
  showScale?: boolean;
  valueLabel?: string | null;
  onClick?: () => void;
  active?: boolean;
  interactiveLabel?: string;
}) {
  const pct = Math.max(0, Math.min(100, (level / maxLevel) * 100));
  const isInteractive = !!onClick;

  return (
    <div className={`wm-tank-card wm-tank-card-${side}`}>
      <div
        className={`wm-tank-shell ${isInteractive ? "wm-clickable" : ""} ${active ? "wm-on" : ""}`}
        onClick={onClick}
        role={isInteractive ? "button" : undefined}
        aria-label={interactiveLabel}
        tabIndex={isInteractive ? 0 : undefined}
        onKeyDown={(e) => {
          if (isInteractive && (e.key === "Enter" || e.key === " ")) {
            e.preventDefault();
            onClick?.();
          }
        }}
      >
        <div className="wm-tank-lid" />
        <div className="wm-tank-body">
          <div className="wm-tank-water" style={{ height: `${pct}%` }} />
          {valueLabel && <div className="wm-tank-value">{valueLabel}</div>}
        </div>
        {showScale && (
          <div className={`wm-scale wm-scale-${side}`}>
            {[100, 90, 80, 70, 60, 50, 40, 30, 20, 10, 0].map((mark) => (
              <span key={mark}>{mark}</span>
            ))}
          </div>
        )}
        {isInteractive && (
          <span className={`wm-state-pill ${active ? "is-on" : "is-off"}`}>
            {active ? "ON" : "OFF"}
          </span>
        )}
      </div>
      <div className="wm-card-title wm-card-title-bottom">{title}</div>
    </div>
  );
}

function Pump({
  label,
  active,
  onClick,
}: {
  label: string;
  active: boolean;
  onClick: () => void;
}) {
  return (
    <div className="wm-pump-block">
      <button
        type="button"
        onClick={onClick}
        className={`wm-pump wm-clickable ${active ? "is-active wm-on" : ""}`}
        aria-label={`Toggle ${label}`}
      >
        <div className="wm-pump-ring" />
        <div className="wm-pump-housing">
          <div className={`wm-pump-fan ${active ? "is-spinning" : ""}`}>
            <span className="wm-pump-blade blade-a" />
            <span className="wm-pump-blade blade-b" />
            <span className="wm-pump-blade blade-c" />
            <span className="wm-pump-blade blade-d" />
          </div>
          <div className="wm-pump-center" />
        </div>
        <div className="wm-pump-port wm-pump-port-left" />
        <div className="wm-pump-port wm-pump-port-right" />
      </button>
      <div className="wm-pump-label wm-pump-label-bottom">
        {label}
        <span className={`wm-state-pill wm-state-pill-sm ${active ? "is-on" : "is-off"}`}>
          {active ? "ON" : "OFF"}
        </span>
      </div>
    </div>
  );
}

function PurificationTank({
  active,
  onClick,
}: {
  active: boolean;
  onClick: () => void;
}) {
  return (
    <div className="wm-purification-card">
      <button
        type="button"
        onClick={onClick}
        className={`wm-purification-tank wm-clickable ${active ? "wm-on" : ""}`}
        aria-label="Toggle purification"
      >
        <div className={`wm-purification-water ${active ? "is-active" : ""}`} aria-hidden="true">
          <span className="wm-purification-blob wm-purification-blob-a" />
          <span className="wm-purification-blob wm-purification-blob-b" />
          <span className="wm-purification-blob wm-purification-blob-c" />
          <span className="wm-purification-blob wm-purification-blob-d" />
          <span className="wm-purification-mist wm-purification-mist-a" />
          <span className="wm-purification-mist wm-purification-mist-b" />
          <span className="wm-purification-glow" />
        </div>
        <div className={`wm-stirrer ${active ? "is-spinning" : ""}`}>
          <span className="wm-stirrer-stick" />
        </div>
      </button>
      <div className="wm-pump-label wm-pump-label-bottom">
        Purifier
        <span className={`wm-state-pill wm-state-pill-sm ${active ? "is-on" : "is-off"}`}>
          {active ? "ON" : "OFF"}
        </span>
      </div>
    </div>
  );
}

export default function WaterSystem({ system }: { system: WaterSystemType }) {
  const {
    mainTankLevel,
    purificationActive,
    pumpR2P,
    pumpP2M,
    togglePumpR2P,
    togglePumpP2M,
    togglePurification,
    PURIFICATION_CAPACITY,
    MAIN_TANK_CAPACITY,
  } = system;

  const purificationRunning = purificationActive;

  return (
    <div className="water-system water-management-diagram">
      <div className="wm-diagram">
        <div className="wm-flow-layout">
          <SideTank
            title="Reservoir"
            level={PURIFICATION_CAPACITY}
            maxLevel={PURIFICATION_CAPACITY}
            side="left"
            showScale={false}
          />
          <PipeSegment flowing={pumpR2P} />
          <Pump label="Pump 1" active={pumpR2P} onClick={togglePumpR2P} />
          <PipeSegment flowing={pumpR2P && purificationActive} />
          <PurificationTank active={purificationRunning} onClick={togglePurification} />
          <PipeSegment flowing={pumpP2M} />
          <Pump label="Pump 2" active={pumpP2M} onClick={togglePumpP2M} />
          <PipeSegment flowing={pumpP2M} />
          <SideTank
            title="Tank 2"
            level={mainTankLevel}
            maxLevel={MAIN_TANK_CAPACITY}
            side="right"
            valueLabel={`${Math.round((mainTankLevel / MAIN_TANK_CAPACITY) * 100)}%`}
          />
        </div>
      </div>
    </div>
  );
}
