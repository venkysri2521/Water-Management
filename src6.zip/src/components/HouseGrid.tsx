import { useState } from "react";
import "./HouseGrid.css";
import type { House, WaterSystem as WaterSystemType } from "@/hooks/useWaterSystem";

const HOUSE_COLORS = ["#3b82f6", "#10b981", "#f59e0b", "#8b5cf6"];

function TapIcon({ active }: { active: boolean }) {
  return (
    <svg width="14" height="14" viewBox="0 0 14 14" fill="none">
      <path d="M2 4h8a2 2 0 012 2v1H2V4z" fill="currentColor" opacity="0.8" />
      <path d="M5 7v5" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
      {active && (
        <path d="M5 12l-1 2M5 12l1 2" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" />
      )}
    </svg>
  );
}

function HouseCard({
  house,
  onToggle,
  onRecharge,
  mainTankLevel,
}: {
  house: House;
  onToggle: (id: number) => void;
  onRecharge: (id: number, amount: number) => void;
  mainTankLevel: number;
}) {
  const [rechargeAmt, setRechargeAmt] = useState(50);
  const color = HOUSE_COLORS[(house.id - 1) % HOUSE_COLORS.length];
  const walletPct = Math.min(100, (house.wallet / 200) * 100);
  const isLowWallet = house.wallet < 30;
  const canConsume = house.wallet > 0 && mainTankLevel > 5;
  const led = house.consuming && canConsume ? "green" : "red";

  return (
    <div
      className="house-card"
      style={{ ["--house-color" as string]: color } as React.CSSProperties}
    >
      <div className="house-icon-area">
        <svg
          width="56"
          height="50"
          viewBox="0 0 56 50"
          fill="none"
          className={`house-svg ${house.consuming && canConsume ? "house-active" : ""}`}
        >
          <polygon points="28,2 52,20 4,20" fill={color} opacity="0.9" />
          <polygon points="28,2 52,20 4,20" fill="none" stroke={color} strokeWidth="1.5" />
          <rect x="8" y="20" width="40" height="28" fill="#f8fafc" stroke="#e2e8f0" strokeWidth="1.5" />
          <rect x="22" y="32" width="12" height="16" rx="6" fill={color} opacity="0.7" />
          <rect x="11" y="24" width="10" height="8" rx="2" fill={color} opacity="0.3" stroke={color} strokeWidth="1" />
          <rect x="35" y="24" width="10" height="8" rx="2" fill={color} opacity="0.3" stroke={color} strokeWidth="1" />
          <rect x="36" y="6" width="6" height="10" fill="#94a3b8" />
        </svg>
        <div className={`led-indicator led-${led}`} />
      </div>

      <div className="house-info">
        <div className="house-name">{house.name}</div>
        <div className="house-id">Unit {String(house.id).padStart(2, "0")}</div>
      </div>

      <div className="wallet-section">
        <div className="wallet-header">
          <span className="wallet-label">Wallet</span>
          <span className={`wallet-amount ${isLowWallet ? "wallet-low" : ""}`}>
            Rs.{house.wallet.toFixed(1)}
          </span>
        </div>
        <div className="wallet-bar-bg">
          <div
            className="wallet-bar-fill"
            style={{ width: `${walletPct}%`, background: isLowWallet ? "#ef4444" : color }}
          />
        </div>
        <div className="wallet-meta">
          <span>{house.consumed.toFixed(1)} L consumed</span>
          <span>Rs.5/L</span>
        </div>
      </div>

      <div className="house-controls">
        <button
          className={`tap-btn ${house.consuming && canConsume ? "tap-on" : "tap-off"}`}
          onClick={() => onToggle(house.id)}
          disabled={!canConsume && !house.consuming}
          style={{ ["--c" as string]: color } as React.CSSProperties}
        >
          <TapIcon active={house.consuming && canConsume} />
          {house.consuming && canConsume ? "Close Tap" : "Open Tap"}
        </button>
        <div className="recharge-row">
          <select
            className="recharge-input"
            value={rechargeAmt}
            onChange={(e) => setRechargeAmt(Number(e.target.value))}
          >
            <option value={10}>Rs.10</option>
            <option value={25}>Rs.25</option>
            <option value={50}>Rs.50</option>
            <option value={100}>Rs.100</option>
          </select>
          <button
            className="recharge-btn"
            style={{ ["--c" as string]: color } as React.CSSProperties}
            onClick={() => onRecharge(house.id, rechargeAmt)}
          >
            + Recharge
          </button>
        </div>
      </div>
    </div>
  );
}

export default function HouseGrid({ system }: { system: WaterSystemType }) {
  const { houses, toggleConsumption, rechargeWallet, mainTankLevel } = system;
  const activeCount = houses.filter((h) => h.consuming).length;

  return (
    <div className="house-grid-wrapper">
      <div className="hg-header">
        <span className="hg-title">Residential Supply</span>
        <span className="hg-sub">{activeCount} Units Active</span>
      </div>
      <div className="house-grid">
        {houses.map((house) => (
          <HouseCard
            key={house.id}
            house={house}
            onToggle={toggleConsumption}
            onRecharge={rechargeWallet}
            mainTankLevel={mainTankLevel}
          />
        ))}
      </div>
    </div>
  );
}
