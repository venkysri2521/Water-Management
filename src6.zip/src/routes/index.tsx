import { createFileRoute } from "@tanstack/react-router";
import AquaFlowApp from "@/components/AquaFlowApp";

export const Route = createFileRoute("/")({
  component: AquaFlowApp,
  head: () => ({
    meta: [
      { title: "AquaFlow IMS — Integrated Water Management" },
      {
        name: "description",
        content:
          "AquaFlow IMS: monitor pipelines, control pumps and purification, and manage residential water supply in real time.",
      },
    ],
  }),
});
