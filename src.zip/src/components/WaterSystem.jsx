import './WaterSystem.css'

const tankGradient = 'linear-gradient(180deg, #67e8f9 0%, #38bdf8 42%, #0ea5e9 72%, #2563eb 100%)'
const sharedTankWrapperStyle = {
  width: 132,
  minWidth: 132,
}
const sharedCylinderStyle = {
  width: 90,
}
const sharedInnerStyle = {
  height: 164,
}
const compactConnectionStyle = {
  marginTop: 16,
}
const purificationOrbitStyle = {
  position: 'absolute',
  top: '58%',
  left: '50%',
  width: 70,
  height: 84,
  transform: 'translate(-50%, -50%)',
  zIndex: 4,
  pointerEvents: 'none',
}
const purificationRingStyle = {
  position: 'absolute',
  left: '50%',
  top: '50%',
  width: 62,
  height: 62,
  marginLeft: -31,
  marginTop: -31,
  transform: 'rotateX(66deg)',
  transformStyle: 'preserve-3d',
  borderRadius: '50%',
  boxShadow: '0 10px 18px rgba(37, 99, 235, 0.08)',
  background: 'radial-gradient(circle at 50% 50%, rgba(255,255,255,0) 26%, rgba(226,232,240,0.52) 27%, rgba(191,219,254,0.5) 38%, rgba(59,130,246,0.78) 39%, rgba(37,99,235,0.86) 58%, rgba(29,78,216,0.92) 78%, rgba(30,64,175,0.96) 100%)',
  animation: 'purification-torus 3.6s ease-in-out infinite',
}
const purificationRingInnerStyle = {
  position: 'absolute',
  inset: 0,
  borderRadius: '50%',
  background: 'radial-gradient(circle at 50% 50%, rgba(255,255,255,0) 0 24%, rgba(10,37,64,0.34) 25%, rgba(14,165,233,0) 41%, rgba(255,255,255,0.08) 52%, rgba(255,255,255,0) 66%)',
  mixBlendMode: 'screen',
  animation: 'purification-torus-sheen 2.8s linear infinite',
}
const purificationCoreStyle = {
  position: 'absolute',
  top: '50%',
  left: '50%',
  width: 18,
  height: 9,
  borderRadius: '50%',
  transform: 'translate(-50%, -50%)',
  background: 'radial-gradient(ellipse at center, rgba(15,23,42,0.9) 0%, rgba(30,41,59,0.82) 55%, rgba(59,130,246,0.16) 100%)',
  boxShadow: 'inset 0 1px 4px rgba(255,255,255,0.08), 0 0 8px rgba(14, 165, 233, 0.12)',
}
const purificationFanStyle = {
  position: 'absolute',
  left: '50%',
  top: '50%',
  width: 16,
  height: 10,
  marginLeft: -8,
  marginTop: -5,
  zIndex: 6,
  transform: 'rotateX(66deg)',
  transformStyle: 'preserve-3d',
  animation: 'purification-fan-spin 1.1s linear infinite',
}
const purificationFanBladeStyle = rotation => ({
  position: 'absolute',
  top: '50%',
  left: '50%',
  width: 8,
  height: 3,
  marginTop: -1.5,
  borderRadius: 999,
  background: 'linear-gradient(90deg, #bfdbfe, #38bdf8, #1d4ed8)',
  boxShadow: '0 0 6px rgba(56, 189, 248, 0.24)',
  transformOrigin: '1px 50%',
  transform: `${rotation} translateX(1px) skewX(-10deg)`,
})
const purificationFanHubStyle = {
  position: 'absolute',
  top: '50%',
  left: '50%',
  width: 6,
  height: 5,
  marginTop: -2.5,
  marginLeft: -3,
  borderRadius: '50%',
  background: 'radial-gradient(circle at 35% 35%, #ffffff, #7dd3fc 50%, #0284c7 100%)',
  boxShadow: '0 0 6px rgba(14, 165, 233, 0.24)',
}
const purificationBubbleStyle = (offset, size = 8) => ({
  position: 'absolute',
  bottom: 29,
  left: '50%',
  width: size,
  height: size,
  marginLeft: size / -2,
  borderRadius: '50%',
  background: 'radial-gradient(circle at 30% 30%, rgba(255,255,255,0.95), rgba(125,211,252,0.9) 55%, rgba(14,165,233,0.75) 100%)',
  boxShadow: '0 0 10px rgba(125, 211, 252, 0.35)',
  animation: 'purification-rise 2.2s ease-in-out infinite',
  animationFillMode: 'both',
  offsetPath: 'path("M 0 0 Q 20 -12 16 -30 Q 8 -48 -10 -62 Q -20 -72 -12 -88")',
  offsetRotate: '0deg',
  animationDelay: offset,
})
const purificationStreamStyle = delay => ({
  position: 'absolute',
  left: '50%',
  bottom: 28,
  width: 7,
  height: 38,
  marginLeft: -3.5,
  borderRadius: 999,
  background: 'linear-gradient(180deg, rgba(186,230,253,0), rgba(125,211,252,0.92) 26%, rgba(56,189,248,0.9) 55%, rgba(14,165,233,0) 100%)',
  filter: 'drop-shadow(0 0 8px rgba(56, 189, 248, 0.22))',
  transformOrigin: 'bottom center',
  animation: 'purification-stream 2s ease-in-out infinite',
  animationDelay: delay,
})

function ReservoirTank() {
  return (
    <div className="tank-wrapper" style={sharedTankWrapperStyle}>
      <div className="tank-label">Reservoir</div>
      <div
        className="reservoir-tank"
        style={{
          width: 90,
          height: 196,
        }}
      >
        <div className="reservoir-head">
          <span className="reservoir-cap reservoir-cap-left" />
          <span className="reservoir-cap reservoir-cap-right" />
        </div>
        <div
          className="reservoir-shell"
          style={{
            top: 10,
            width: 70,
            height: 96,
            background: tankGradient,
          }}
        >
          <div className="reservoir-inner" style={{ background: tankGradient }} />
          <div className="reservoir-icons" aria-hidden="true">
            <div className="reservoir-icon-drop" />
            <div className="reservoir-icon-waves">
              <span />
              <span />
              <span />
            </div>
          </div>
        </div>
        <div className="reservoir-band" style={{ top: 110, width: 72 }} />
        <div className="reservoir-frame" style={{ top: 116, width: 72, height: 62 }}>
          <div className="reservoir-support reservoir-support-left" />
          <div className="reservoir-support reservoir-support-right" />
          <div className="reservoir-crossbeam reservoir-crossbeam-top" />
          <div className="reservoir-crossbeam reservoir-crossbeam-bottom" />
        </div>
        <div className="reservoir-bottom-shadow" />
      </div>
    </div>
  )
}

function PurificationTank({ level, maxLevel = 1000, active }) {
  const pct = Math.min(100, (level / maxLevel) * 100)

  return (
    <div className="tank-wrapper" style={sharedTankWrapperStyle}>
      <div className="tank-label">Purification Tank</div>
      <div className="tank purification-tank">
        <div className="tank-body">
          <div className="tank-legs">
            <div className="leg" />
            <div className="leg" />
          </div>
          <div className="tank-cylinder" style={sharedCylinderStyle}>
            <div className="tank-top-cap" />
            <div className="tank-inner" style={sharedInnerStyle}>
              <div
                className="water-fill"
                style={{ height: `${pct}%`, background: tankGradient }}
              >
                <div className="water-wave" />
              </div>
              {active && (
                <div style={purificationOrbitStyle}>
                  <div style={purificationRingStyle}>
                    <div style={purificationRingInnerStyle} />
                  </div>
                  <div style={purificationStreamStyle('0s')} />
                  <div style={purificationStreamStyle('-1s')} />
                  <div style={purificationBubbleStyle('0s', 8)} />
                  <div style={purificationBubbleStyle('-0.7s', 7)} />
                  <div style={purificationBubbleStyle('-1.4s', 6)} />
                  <div style={purificationCoreStyle} />
                  <div style={purificationFanStyle}>
                    <div style={purificationFanBladeStyle('rotate(0deg)')} />
                    <div style={purificationFanBladeStyle('rotate(120deg)')} />
                    <div style={purificationFanBladeStyle('rotate(240deg)')} />
                    <div style={purificationFanHubStyle} />
                  </div>
                </div>
              )}
              <div
                className="water-percentage"
                style={{ top: '43%', zIndex: 8 }}
              >
                {pct.toFixed(0)}%
              </div>
              <div className={`purif-status ${active ? 'active' : ''}`}>
                {active ? 'PURIFYING' : 'STANDBY'}
              </div>
            </div>
            <div className="tank-bottom-cap" />
          </div>
        </div>
      </div>
      <div className="tank-stats">
        <span>{level.toFixed(0)} / {maxLevel} ml</span>
      </div>
    </div>
  )
}

function MainTank({ level, maxLevel = 500 }) {
  const pct = Math.min(100, (level / maxLevel) * 100)
  const isLow = pct <= 20

  return (
    <div className="tank-wrapper" style={sharedTankWrapperStyle}>
      <div className="tank-label">Main Tank {isLow && <span className="low-badge">LOW</span>}</div>
      <div className="tank main-tank">
        <div className="tank-body">
          <div className="tank-legs">
            <div className="leg" />
            <div className="leg" />
          </div>
          <div className="tank-cylinder main-cylinder" style={sharedCylinderStyle}>
            <div className="tank-top-cap" />
            <div className="tank-inner" style={sharedInnerStyle}>
              <div
                className="water-fill"
                style={{ height: `${pct}%`, background: tankGradient }}
              >
                <div className="water-wave" />
              </div>
              <div className="water-percentage">{pct.toFixed(0)}%</div>
            </div>
            <div className="tank-bottom-cap" />
          </div>
        </div>
      </div>
      <div className="tank-stats">
        <span>{level.toFixed(0)} / {maxLevel} ml</span>
      </div>
    </div>
  )
}

function Motor({ active, label, flowRate, attack }) {
  const motorHousingStyle = !active
    ? {
        background: 'linear-gradient(135deg, #fee2e2, #fca5a5)',
        borderColor: '#ef4444',
        boxShadow: '0 3px 8px rgba(239,68,68,0.18), inset 0 1px 0 rgba(255,255,255,0.45)',
      }
    : undefined
  const motorLabelStyle = !active
    ? {
        color: '#991b1b',
      }
    : undefined
  const fanBladeStyle = !active
    ? {
        background: 'linear-gradient(90deg, #b91c1c, #ef4444)',
        opacity: 0.9,
      }
    : undefined
  const fanCenterStyle = !active
    ? {
        background: '#dc2626',
        boxShadow: '0 0 6px rgba(220,38,38,0.35)',
      }
    : undefined

  return (
    <div className={`motor-wrapper ${attack ? 'motor-attack' : ''}`}>
      <div className={`motor-body ${active ? 'motor-on' : ''}`}>
        <div className="motor-housing" style={motorHousingStyle}>
          <div className="motor-label-inner" style={motorLabelStyle}>M</div>
          <div className={`motor-fan ${active ? 'fan-spin' : ''}`}>
            <div className="fan-blade fb1" style={fanBladeStyle} />
            <div className="fan-blade fb2" style={fanBladeStyle} />
            <div className="fan-blade fb3" style={fanBladeStyle} />
            <div className="fan-blade fb4" style={fanBladeStyle} />
            <div className="fan-center" style={fanCenterStyle} />
          </div>
        </div>
        <div className={`motor-status-dot ${active ? 'dot-on' : 'dot-off'}`} />
      </div>
      <div className="motor-info">
        <span className="motor-name">{label}</span>
        {active && <span className="motor-flow">{flowRate?.toFixed(1)} ml/s</span>}
      </div>
    </div>
  )
}

function Pipe({ flowing, vertical, length, attack }) {
  return (
    <div className={`pipe ${vertical ? 'pipe-v' : 'pipe-h'} ${attack ? 'pipe-attack' : ''}`}
      style={{ [vertical ? 'height' : 'width']: length || 60 }}>
      {flowing && <div className={`flow-indicator ${vertical ? 'flow-v' : 'flow-h'}`} />}
    </div>
  )
}

export default function WaterSystem({ system }) {
  const {
    purificationLevel, mainTankLevel,
    purificationActive, pumpR2P, pumpP2M,
    flowRateR2P, flowRateP2M,
    modbusAttack,
    PURIFICATION_CAPACITY, MAIN_TANK_CAPACITY,
  } = system

  return (
    <div className="water-system">
      <style>{`
        @keyframes purification-torus {
          0% {
            transform: rotateX(66deg) rotateZ(0deg) scale(1);
            opacity: 0.92;
          }
          50% {
            transform: rotateX(66deg) rotateZ(180deg) scale(1.04);
            opacity: 1;
          }
          100% {
            transform: rotateX(66deg) rotateZ(360deg) scale(1);
            opacity: 0.92;
          }
        }

        @keyframes purification-torus-sheen {
          0% {
            transform: rotate(0deg);
            opacity: 0.35;
          }
          50% {
            opacity: 0.65;
          }
          100% {
            transform: rotate(360deg);
            opacity: 0.35;
          }
        }

        @keyframes purification-rise {
          0% {
            offset-distance: 0%;
            opacity: 0;
            transform: scale(0.7);
          }
          20% {
            opacity: 0.95;
          }
          70% {
            opacity: 0.9;
          }
          100% {
            offset-distance: 100%;
            opacity: 0;
            transform: scale(1.05);
          }
        }

        @keyframes purification-stream {
          0% {
            transform: translateX(-8px) translateY(0) rotate(-24deg) scaleY(0.55);
            opacity: 0;
          }
          25% {
            opacity: 0.72;
          }
          100% {
            transform: translateX(-12px) translateY(-34px) rotate(-24deg) scaleY(1.18);
            opacity: 0;
          }
        }

        @keyframes purification-fan-spin {
          from {
            transform: rotateX(66deg) rotateZ(0deg);
          }
          to {
            transform: rotateX(66deg) rotateZ(360deg);
          }
        }
      `}</style>
      <div className="pipeline-row" style={{ gap: 12 }}>
        {/* Reservoir Tank */}
        <ReservoirTank />

        {/* Connection: Reservoir → Motor → Purification */}
        <div className="connection" style={compactConnectionStyle}>
          <Pipe flowing={pumpR2P} length={36} />
          <Motor
            active={pumpR2P}
            label="Pump 1"
            flowRate={flowRateR2P}
          />
          <Pipe flowing={pumpR2P} length={36} />
        </div>

        {/* Purification Tank */}
        <PurificationTank
          level={purificationLevel}
          maxLevel={PURIFICATION_CAPACITY}
          active={purificationActive && purificationLevel > 0}
        />

        {/* Connection: Purification → Motor → Main Tank */}
        <div className="connection" style={compactConnectionStyle}>
          <Pipe flowing={pumpP2M} attack={modbusAttack} length={36} />
          <Motor
            active={pumpP2M}
            label="Pump 2"
            flowRate={flowRateP2M}
            attack={modbusAttack}
          />
          <Pipe flowing={pumpP2M} attack={modbusAttack} length={36} />
        </div>

        {/* Main Tank */}
        <MainTank level={mainTankLevel} maxLevel={MAIN_TANK_CAPACITY} />
      </div>
    </div>
  )
}
